import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:onelingo/core/aprendizaje/biblioteca_adaptador.dart';
import 'package:onelingo/core/aprendizaje/biblioteca_modelos.dart';

void main() {
  ExerciseVariant variant(String format, Map<String, dynamic> answer) =>
      ExerciseVariant(
        id: 'ex.u:v1:practice',
        format: format,
        prompt: const {'es': 'Elige'},
        answer: answer,
        choices: const [
          {'text': 'hello'},
        ],
        teaches: const [],
        requires: const [],
        origin: const {},
        contentHash: 'sha256:x',
      );

  test('adapta formatos y respuesta sin cambiar el id estable', () {
    final item = itemDesdeVariante(variant('choice', {'index': 0}));
    expect(item.id, 'ex.u:v1:practice');
    expect(item.formato.name, 'elegir');
    expect(item.indiceRespuesta, 0);
  });

  test('legacy es seguro por defecto y shadow conserva diagnóstico', () async {
    const activation = ActivacionBiblioteca();
    final result = await CargadorBiblioteca().diagnostico(
      'en',
      'u',
      activation,
    );
    expect(result.activacion, EstadoBiblioteca.legacy);
    expect(result.aplicaAlAlumno, isFalse);
  });

  test('distingue biblioteca ausente de inválida', () async {
    final bundle = TestAssetBundle({
      CargadorBiblioteca.asset('bad'): '{not json',
    });
    final loader = CargadorBiblioteca(bundle: bundle);
    expect(
      (await loader.cargar('missing')).estado,
      EstadoCargaBiblioteca.ausente,
    );
    expect((await loader.cargar('bad')).estado, EstadoCargaBiblioteca.invalida);
  });

  test('active exige review y shadow nunca sustituye la ruta', () async {
    final bundle = TestAssetBundle({
      CargadorBiblioteca.asset('en'): '''
        {"schema":"exercise-library/1","libraryId":"x","version":"1","course":"en",
         "units":{"u":{"concepts":[],"skills":[],"prerequisites":[],"pools":{}}},
         "families":[]}
      ''',
    });
    final loader = CargadorBiblioteca(bundle: bundle);
    final shadow = await loader.diagnostico(
      'en',
      'u',
      const ActivacionBiblioteca(porUnidad: {'u': EstadoBiblioteca.shadow}),
    );
    expect(shadow.validaEnSombra, isTrue);
    expect(shadow.aplicaAlAlumno, isFalse);
    final active = await loader.diagnostico(
      'en',
      'u',
      const ActivacionBiblioteca(porUnidad: {'u': EstadoBiblioteca.active}),
    );
    expect(active.aplicaAlAlumno, isFalse);
    expect(active.errores.single, contains('without editorial review'));
  });
}

class TestAssetBundle extends CachingAssetBundle {
  TestAssetBundle(this.assets);
  final Map<String, String> assets;

  @override
  Future<ByteData> load(String key) async {
    final value = assets[key];
    if (value == null) throw StateError('missing $key');
    final bytes = Uint8List.fromList(utf8.encode(value));
    return ByteData.sublistView(bytes);
  }
}
